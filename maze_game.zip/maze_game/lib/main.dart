import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(const MazeApp());
}

class MazeApp extends StatelessWidget {
  const MazeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Maze Game',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
      ),
      home: const MazeHomePage(),
    );
  }
}

class MazeHomePage extends StatefulWidget {
  const MazeHomePage({super.key});

  @override
  State<MazeHomePage> createState() => _MazeHomePageState();
}

class _MazeHomePageState extends State<MazeHomePage> {
  static const int rows = 15;
  static const int cols = 15;
  late Maze _maze;
  late Point<int> _player;
  late Point<int> _goal;
  bool _won = false;

  @override
  void initState() {
    super.initState();
    _resetMaze();
  }

  void _resetMaze() {
    _maze = MazeGenerator(rows: rows, cols: cols, seed: DateTime.now().millisecondsSinceEpoch).generate();
    _player = const Point(0, 0);
    _goal = Point(cols - 1, rows - 1);
    _won = false;
    setState(() {});
  }

  void _tryMove(int dx, int dy) {
    if (_won) return;
    final int nx = _player.x + dx;
    final int ny = _player.y + dy;
    if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) return;

    // Check walls between current and next cell
    final Cell current = _maze.grid[_player.y][_player.x];
    if (dx == 1 && current.walls.right) return;
    if (dx == -1 && current.walls.left) return;
    if (dy == 1 && current.walls.bottom) return;
    if (dy == -1 && current.walls.top) return;

    setState(() {
      _player = Point(nx, ny);
      if (_player == _goal) {
        _won = true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _showWinDialog();
        });
      }
    });
  }

  void _showWinDialog() async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('أحسنت!'),
          content: const Text('لقد خرجت من المتاهة! هل تريد اللعب مجددًا؟'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                _resetMaze();
              },
              child: const Text('جولة جديدة'),
            ),
          ],
        );
      },
    );
  }

  // Swipe gesture handling
  Offset? _dragStart;
  void _onPanStart(DragStartDetails d) {
    _dragStart = d.localPosition;
  }

  void _onPanUpdate(DragUpdateDetails d) {}

  void _onPanEnd(DragEndDetails d, Size size) {
    if (_dragStart == null) return;
    final Offset end = _dragStart! + d.velocity.pixelsPerSecond / 20.0;
    final Offset delta = end - _dragStart!;
    if (delta.distance < 10) return;
    if (delta.dx.abs() > delta.dy.abs()) {
      _tryMove(delta.dx > 0 ? 1 : -1, 0);
    } else {
      _tryMove(0, delta.dy > 0 ? 1 : -1);
    }
    _dragStart = null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Maze Game – لعبة المتاهة'),
        actions: [
          IconButton(
            tooltip: 'إعادة توليد المتاهة',
            onPressed: _resetMaze,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final double size = min(constraints.maxWidth, constraints.maxHeight - 120);
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: GestureDetector(
                  onPanStart: _onPanStart,
                  onPanUpdate: _onPanUpdate,
                  onPanEnd: (d) => _onPanEnd(d, Size(size, size)),
                  child: SizedBox(
                    width: size,
                    height: size,
                    child: CustomPaint(
                      painter: MazePainter(
                        maze: _maze,
                        player: _player,
                        goal: _goal,
                        playerColor: Colors.orange,
                        wallColor: Colors.black87,
                        pathColor: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _buildControls(),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  _won ? '🎉 خرجت من المتاهة! اضغط إعادة للمزيد.' : 'اسحب أو استخدم الأسهم للتحرك',
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildControls() {
    final ButtonStyle style = ElevatedButton.styleFrom(minimumSize: const Size(56, 48));
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => _tryMove(0, -1),
              style: style,
              child: const Icon(Icons.keyboard_arrow_up),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => _tryMove(-1, 0),
              style: style,
              child: const Icon(Icons.keyboard_arrow_left),
            ),
            const SizedBox(width: 12),
            ElevatedButton(
              onPressed: _resetMaze,
              style: ElevatedButton.styleFrom(minimumSize: const Size(56, 48), backgroundColor: Colors.indigo.shade100),
              child: const Icon(Icons.refresh, color: Colors.black87),
            ),
            const SizedBox(width: 12),
            ElevatedButton(
              onPressed: () => _tryMove(1, 0),
              style: style,
              child: const Icon(Icons.keyboard_arrow_right),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => _tryMove(0, 1),
              style: style,
              child: const Icon(Icons.keyboard_arrow_down),
            ),
          ],
        ),
      ],
    );
  }
}

class Maze {
  Maze({required this.rows, required this.cols, required this.grid});
  final int rows;
  final int cols;
  final List<List<Cell>> grid;
}

class CellWalls {
  CellWalls({this.top = true, this.right = true, this.bottom = true, this.left = true});
  bool top;
  bool right;
  bool bottom;
  bool left;
}

class Cell {
  Cell(this.x, this.y) : walls = CellWalls();
  final int x;
  final int y;
  final CellWalls walls;
  bool visited = false;
}

class MazeGenerator {
  MazeGenerator({required this.rows, required this.cols, int? seed})
      : _random = Random(seed);
  final int rows;
  final int cols;
  final Random _random;

  Maze generate() {
    final List<List<Cell>> grid = List.generate(rows, (y) => List.generate(cols, (x) => Cell(x, y)));
    final List<Cell> stack = <Cell>[];

    Cell current = grid[0][0];
    current.visited = true;
    int visitedCount = 1;
    final int total = rows * cols;

    while (visitedCount < total) {
      final List<Cell> neighbors = _unvisitedNeighbors(current, grid);
      if (neighbors.isNotEmpty) {
        final Cell next = neighbors[_random.nextInt(neighbors.length)];
        _removeWall(current, next);
        stack.add(current);
        current = next;
        current.visited = true;
        visitedCount++;
      } else if (stack.isNotEmpty) {
        current = stack.removeLast();
      }
    }

    // Cleanup visited flags
    for (final row in grid) {
      for (final cell in row) {
        cell.visited = false;
      }
    }

    return Maze(rows: rows, cols: cols, grid: grid);
  }

  List<Cell> _unvisitedNeighbors(Cell c, List<List<Cell>> grid) {
    final List<Cell> n = <Cell>[];
    if (c.y > 0 && !grid[c.y - 1][c.x].visited) n.add(grid[c.y - 1][c.x]);
    if (c.x < cols - 1 && !grid[c.y][c.x + 1].visited) n.add(grid[c.y][c.x + 1]);
    if (c.y < rows - 1 && !grid[c.y + 1][c.x].visited) n.add(grid[c.y + 1][c.x]);
    if (c.x > 0 && !grid[c.y][c.x - 1].visited) n.add(grid[c.y][c.x - 1]);
    return n;
  }

  void _removeWall(Cell a, Cell b) {
    final int dx = b.x - a.x;
    final int dy = b.y - a.y;
    if (dx == 1) {
      a.walls.right = false;
      b.walls.left = false;
    } else if (dx == -1) {
      a.walls.left = false;
      b.walls.right = false;
    } else if (dy == 1) {
      a.walls.bottom = false;
      b.walls.top = false;
    } else if (dy == -1) {
      a.walls.top = false;
      b.walls.bottom = false;
    }
  }
}

class MazePainter extends CustomPainter {
  MazePainter({
    required this.maze,
    required this.player,
    required this.goal,
    required this.playerColor,
    required this.wallColor,
    required this.pathColor,
  });

  final Maze maze;
  final Point<int> player;
  final Point<int> goal;
  final Color playerColor;
  final Color wallColor;
  final Color pathColor;

  @override
  void paint(Canvas canvas, Size size) {
    final double cellW = size.width / maze.cols;
    final double cellH = size.height / maze.rows;

    final Paint bgPaint = Paint()..color = pathColor;
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    final Paint wallPaint = Paint()
      ..color = wallColor
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    // Draw walls
    for (int y = 0; y < maze.rows; y++) {
      for (int x = 0; x < maze.cols; x++) {
        final Cell c = maze.grid[y][x];
        final double left = x * cellW;
        final double top = y * cellH;
        final double right = left + cellW;
        final double bottom = top + cellH;

        if (c.walls.top) {
          canvas.drawLine(Offset(left, top), Offset(right, top), wallPaint);
        }
        if (c.walls.right) {
          canvas.drawLine(Offset(right, top), Offset(right, bottom), wallPaint);
        }
        if (c.walls.bottom) {
          canvas.drawLine(Offset(left, bottom), Offset(right, bottom), wallPaint);
        }
        if (c.walls.left) {
          canvas.drawLine(Offset(left, top), Offset(left, bottom), wallPaint);
        }
      }
    }

    // Draw goal
    final Paint goalPaint = Paint()..color = Colors.greenAccent.shade400;
    final Rect goalRect = Rect.fromLTWH(
      goal.x * cellW + cellW * 0.2,
      goal.y * cellH + cellH * 0.2,
      cellW * 0.6,
      cellH * 0.6,
    );
    canvas.drawRRect(RRect.fromRectAndRadius(goalRect, const Radius.circular(6)), goalPaint);

    // Draw player
    final Paint playerPaint = Paint()..color = playerColor;
    final Offset center = Offset(
      player.x * cellW + cellW / 2,
      player.y * cellH + cellH / 2,
    );
    canvas.drawCircle(center, min(cellW, cellH) * 0.3, playerPaint);
  }

  @override
  bool shouldRepaint(covariant MazePainter oldDelegate) {
    return oldDelegate.maze != maze ||
        oldDelegate.player != player ||
        oldDelegate.goal != goal ||
        oldDelegate.playerColor != playerColor ||
        oldDelegate.wallColor != wallColor ||
        oldDelegate.pathColor != pathColor;
  }
}
