# Maze Game – متاهة بدون إنترنت

هذا المستودع يُجهّز مشروع لعبة "Maze Game" ويحتوي على ملفات المتجر (Google Play) ووثائق البدء. اختر محرك التطوير المفضل لديك، ثم سنُنشئ الهيكل والشفرة تلقائيًا.

## خيارات المحرك
- Android Native (Kotlin)
- Flutter
- Godot 4 (GDScript)

يرجى إخباري بالمحرك الذي تفضله لنبدأ التوليد البرمجي.

## ملفات المتجر
- `metadata/google-play/ar/title.txt`
- `metadata/google-play/ar/short_description.txt`
- `metadata/google-play/ar/full_description.txt`

## سياسة الخصوصية
التطبيق لا يجمع أي بيانات شخصية ولا يطلب صلاحيات. انظر `PRIVACY_POLICY.md`.

## الخطوات التالية
1. اختيار المحرك.
2. إنشاء هيكل المشروع والشفرة الأساسية.
3. إضافة الأيقونات ولقطات الشاشة لاحقًا.



